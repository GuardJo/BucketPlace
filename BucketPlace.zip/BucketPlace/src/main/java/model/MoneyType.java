package model;

public enum MoneyType {
    WON, DALLER, UNKNOWN
}
