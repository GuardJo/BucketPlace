package model;

public enum UserType {
    USER, UNKNOWN
}
