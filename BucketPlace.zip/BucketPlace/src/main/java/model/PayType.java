package model;

public enum PayType {
    CREDIT_CARD, ACOOUNT, OPEN_BANKING, O_JIP_PAY, UNKNOWN
}
